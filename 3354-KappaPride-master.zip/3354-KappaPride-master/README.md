# 3354-KappaPride

This is concerning Amrr's commit history. The reason that he doesn't have a lot of commits is because his laptop got stolen, so he was unable to work on the project when we met every week on Wednesday. To work around this problem, we pair programmed with him, so that way he also got to work on the code.
